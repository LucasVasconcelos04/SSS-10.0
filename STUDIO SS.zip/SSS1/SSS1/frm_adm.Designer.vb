﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_adm
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_adm))
        TabControl1 = New TabControl()
        TabPage1 = New TabPage()
        TabPage2 = New TabPage()
        btn_excluir = New Button()
        cmb_id_cargo = New ComboBox()
        Label2 = New Label()
        Label1 = New Label()
        foto_3x4 = New PictureBox()
        txt_city = New MaskedTextBox()
        Label28 = New Label()
        txt_uf = New MaskedTextBox()
        Label27 = New Label()
        btn_cadastrar = New Button()
        txt_telfixo = New MaskedTextBox()
        Label14 = New Label()
        txt_wpp = New MaskedTextBox()
        Label13 = New Label()
        txt_comp = New MaskedTextBox()
        Label12 = New Label()
        Label11 = New Label()
        cmb_data = New DateTimePicker()
        txt_bairro = New MaskedTextBox()
        Label10 = New Label()
        txt_n = New MaskedTextBox()
        Label9 = New Label()
        txt_rua = New MaskedTextBox()
        Label8 = New Label()
        txt_cep = New MaskedTextBox()
        Label7 = New Label()
        txt_email = New MaskedTextBox()
        Label6 = New Label()
        txt_nome = New MaskedTextBox()
        Label5 = New Label()
        txt_cpf = New MaskedTextBox()
        Label4 = New Label()
        Label3 = New Label()
        PictureBox2 = New PictureBox()
        OpenFileDialog1 = New OpenFileDialog()
        btn_salvar = New Button()
        TabControl1.SuspendLayout()
        TabPage2.SuspendLayout()
        CType(foto_3x4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' TabControl1
        ' 
        TabControl1.Controls.Add(TabPage1)
        TabControl1.Controls.Add(TabPage2)
        TabControl1.Location = New Point(1, 1)
        TabControl1.Name = "TabControl1"
        TabControl1.SelectedIndex = 0
        TabControl1.Size = New Size(675, 660)
        TabControl1.TabIndex = 0
        ' 
        ' TabPage1
        ' 
        TabPage1.Location = New Point(4, 24)
        TabPage1.Name = "TabPage1"
        TabPage1.Padding = New Padding(3)
        TabPage1.Size = New Size(667, 632)
        TabPage1.TabIndex = 0
        TabPage1.Text = "TabPage1"
        TabPage1.UseVisualStyleBackColor = True
        ' 
        ' TabPage2
        ' 
        TabPage2.BackColor = Color.Black
        TabPage2.Controls.Add(btn_salvar)
        TabPage2.Controls.Add(btn_excluir)
        TabPage2.Controls.Add(cmb_id_cargo)
        TabPage2.Controls.Add(Label2)
        TabPage2.Controls.Add(Label1)
        TabPage2.Controls.Add(foto_3x4)
        TabPage2.Controls.Add(txt_city)
        TabPage2.Controls.Add(Label28)
        TabPage2.Controls.Add(txt_uf)
        TabPage2.Controls.Add(Label27)
        TabPage2.Controls.Add(btn_cadastrar)
        TabPage2.Controls.Add(txt_telfixo)
        TabPage2.Controls.Add(Label14)
        TabPage2.Controls.Add(txt_wpp)
        TabPage2.Controls.Add(Label13)
        TabPage2.Controls.Add(txt_comp)
        TabPage2.Controls.Add(Label12)
        TabPage2.Controls.Add(Label11)
        TabPage2.Controls.Add(cmb_data)
        TabPage2.Controls.Add(txt_bairro)
        TabPage2.Controls.Add(Label10)
        TabPage2.Controls.Add(txt_n)
        TabPage2.Controls.Add(Label9)
        TabPage2.Controls.Add(txt_rua)
        TabPage2.Controls.Add(Label8)
        TabPage2.Controls.Add(txt_cep)
        TabPage2.Controls.Add(Label7)
        TabPage2.Controls.Add(txt_email)
        TabPage2.Controls.Add(Label6)
        TabPage2.Controls.Add(txt_nome)
        TabPage2.Controls.Add(Label5)
        TabPage2.Controls.Add(txt_cpf)
        TabPage2.Controls.Add(Label4)
        TabPage2.Controls.Add(Label3)
        TabPage2.Controls.Add(PictureBox2)
        TabPage2.Location = New Point(4, 24)
        TabPage2.Name = "TabPage2"
        TabPage2.Padding = New Padding(3)
        TabPage2.Size = New Size(667, 632)
        TabPage2.TabIndex = 1
        TabPage2.Text = "CADASTRO DE FUNCIONÁRIOS"
        ' 
        ' btn_excluir
        ' 
        btn_excluir.BackColor = Color.Coral
        btn_excluir.Font = New Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        btn_excluir.ForeColor = Color.Black
        btn_excluir.Image = CType(resources.GetObject("btn_excluir.Image"), Image)
        btn_excluir.Location = New Point(557, 537)
        btn_excluir.Name = "btn_excluir"
        btn_excluir.Size = New Size(85, 74)
        btn_excluir.TabIndex = 63
        btn_excluir.Text = "EXCLUIR"
        btn_excluir.TextAlign = ContentAlignment.BottomCenter
        btn_excluir.UseVisualStyleBackColor = False
        ' 
        ' cmb_id_cargo
        ' 
        cmb_id_cargo.FormattingEnabled = True
        cmb_id_cargo.Items.AddRange(New Object() {"1", "2"})
        cmb_id_cargo.Location = New Point(357, 275)
        cmb_id_cargo.Name = "cmb_id_cargo"
        cmb_id_cargo.Size = New Size(48, 23)
        cmb_id_cargo.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.ForeColor = SystemColors.Info
        Label2.Location = New Point(357, 257)
        Label2.Name = "Label2"
        Label2.Size = New Size(81, 15)
        Label2.TabIndex = 62
        Label2.Text = "ID DO CARGO"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.ForeColor = SystemColors.Info
        Label1.Location = New Point(445, 111)
        Label1.Name = "Label1"
        Label1.Size = New Size(56, 15)
        Label1.TabIndex = 61
        Label1.Text = "FOTO 3x4"
        ' 
        ' foto_3x4
        ' 
        foto_3x4.BackColor = Color.White
        foto_3x4.BorderStyle = BorderStyle.Fixed3D
        foto_3x4.Image = CType(resources.GetObject("foto_3x4.Image"), Image)
        foto_3x4.Location = New Point(444, 130)
        foto_3x4.Name = "foto_3x4"
        foto_3x4.Size = New Size(107, 98)
        foto_3x4.SizeMode = PictureBoxSizeMode.StretchImage
        foto_3x4.TabIndex = 60
        foto_3x4.TabStop = False
        ' 
        ' txt_city
        ' 
        txt_city.Location = New Point(241, 457)
        txt_city.Name = "txt_city"
        txt_city.Size = New Size(164, 23)
        txt_city.TabIndex = 59
        ' 
        ' Label28
        ' 
        Label28.AutoSize = True
        Label28.ForeColor = SystemColors.Info
        Label28.Location = New Point(241, 439)
        Label28.Name = "Label28"
        Label28.Size = New Size(48, 15)
        Label28.TabIndex = 58
        Label28.Text = "CIDADE"
        ' 
        ' txt_uf
        ' 
        txt_uf.Location = New Point(432, 457)
        txt_uf.Name = "txt_uf"
        txt_uf.Size = New Size(21, 23)
        txt_uf.TabIndex = 57
        ' 
        ' Label27
        ' 
        Label27.AutoSize = True
        Label27.ForeColor = SystemColors.Info
        Label27.Location = New Point(432, 439)
        Label27.Name = "Label27"
        Label27.Size = New Size(21, 15)
        Label27.TabIndex = 56
        Label27.Text = "UF"
        ' 
        ' btn_cadastrar
        ' 
        btn_cadastrar.BackColor = Color.Coral
        btn_cadastrar.Font = New Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        btn_cadastrar.Image = CType(resources.GetObject("btn_cadastrar.Image"), Image)
        btn_cadastrar.ImageAlign = ContentAlignment.TopCenter
        btn_cadastrar.Location = New Point(557, 439)
        btn_cadastrar.Name = "btn_cadastrar"
        btn_cadastrar.Size = New Size(85, 74)
        btn_cadastrar.TabIndex = 55
        btn_cadastrar.Text = "CADASTRAR"
        btn_cadastrar.TextAlign = ContentAlignment.BottomCenter
        btn_cadastrar.UseVisualStyleBackColor = False
        ' 
        ' txt_telfixo
        ' 
        txt_telfixo.Location = New Point(178, 512)
        txt_telfixo.Mask = "(00) 0000-0000"
        txt_telfixo.Name = "txt_telfixo"
        txt_telfixo.Size = New Size(89, 23)
        txt_telfixo.TabIndex = 54
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.ForeColor = SystemColors.Info
        Label14.Location = New Point(178, 494)
        Label14.Name = "Label14"
        Label14.Size = New Size(53, 15)
        Label14.TabIndex = 53
        Label14.Text = "TEL FIXO"
        ' 
        ' txt_wpp
        ' 
        txt_wpp.Location = New Point(20, 512)
        txt_wpp.Mask = "(00) 99999-9999"
        txt_wpp.Name = "txt_wpp"
        txt_wpp.Size = New Size(89, 23)
        txt_wpp.TabIndex = 52
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.ForeColor = SystemColors.Info
        Label13.Location = New Point(20, 494)
        Label13.Name = "Label13"
        Label13.Size = New Size(89, 15)
        Label13.TabIndex = 51
        Label13.Text = "TEL WHATSAPP"
        ' 
        ' txt_comp
        ' 
        txt_comp.Location = New Point(329, 393)
        txt_comp.Name = "txt_comp"
        txt_comp.Size = New Size(38, 23)
        txt_comp.TabIndex = 50
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.ForeColor = SystemColors.Info
        Label12.Location = New Point(329, 375)
        Label12.Name = "Label12"
        Label12.Size = New Size(94, 15)
        Label12.TabIndex = 49
        Label12.Text = "COMPLEMENTO"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.ForeColor = SystemColors.Info
        Label11.Location = New Point(251, 147)
        Label11.Name = "Label11"
        Label11.Size = New Size(129, 15)
        Label11.TabIndex = 48
        Label11.Text = "DATA DE NASCIMENTO"
        ' 
        ' cmb_data
        ' 
        cmb_data.Format = DateTimePickerFormat.Short
        cmb_data.Location = New Point(251, 165)
        cmb_data.MaxDate = New Date(2005, 8, 31, 0, 0, 0, 0)
        cmb_data.MinDate = New Date(1955, 1, 1, 0, 0, 0, 0)
        cmb_data.Name = "cmb_data"
        cmb_data.Size = New Size(95, 23)
        cmb_data.TabIndex = 47
        cmb_data.Value = New Date(2005, 8, 31, 0, 0, 0, 0)
        ' 
        ' txt_bairro
        ' 
        txt_bairro.Location = New Point(20, 457)
        txt_bairro.Name = "txt_bairro"
        txt_bairro.Size = New Size(200, 23)
        txt_bairro.TabIndex = 46
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.ForeColor = SystemColors.Info
        Label10.Location = New Point(20, 439)
        Label10.Name = "Label10"
        Label10.Size = New Size(48, 15)
        Label10.TabIndex = 45
        Label10.Text = "BAIRRO"
        ' 
        ' txt_n
        ' 
        txt_n.Location = New Point(231, 393)
        txt_n.Name = "txt_n"
        txt_n.Size = New Size(65, 23)
        txt_n.TabIndex = 44
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.ForeColor = SystemColors.Info
        Label9.Location = New Point(231, 375)
        Label9.Name = "Label9"
        Label9.Size = New Size(24, 15)
        Label9.TabIndex = 43
        Label9.Text = "Nº "
        ' 
        ' txt_rua
        ' 
        txt_rua.Location = New Point(20, 393)
        txt_rua.Name = "txt_rua"
        txt_rua.Size = New Size(181, 23)
        txt_rua.TabIndex = 5
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.ForeColor = SystemColors.Info
        Label8.Location = New Point(20, 375)
        Label8.Name = "Label8"
        Label8.Size = New Size(30, 15)
        Label8.TabIndex = 41
        Label8.Text = "RUA"
        ' 
        ' txt_cep
        ' 
        txt_cep.Location = New Point(20, 332)
        txt_cep.Mask = "00000-000"
        txt_cep.Name = "txt_cep"
        txt_cep.Size = New Size(64, 23)
        txt_cep.TabIndex = 4
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.ForeColor = SystemColors.Info
        Label7.Location = New Point(20, 314)
        Label7.Name = "Label7"
        Label7.Size = New Size(28, 15)
        Label7.TabIndex = 39
        Label7.Text = "CEP"
        ' 
        ' txt_email
        ' 
        txt_email.Location = New Point(20, 275)
        txt_email.Name = "txt_email"
        txt_email.Size = New Size(288, 23)
        txt_email.TabIndex = 2
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.ForeColor = SystemColors.Info
        Label6.Location = New Point(20, 257)
        Label6.Name = "Label6"
        Label6.Size = New Size(41, 15)
        Label6.TabIndex = 37
        Label6.Text = "EMAIL"
        ' 
        ' txt_nome
        ' 
        txt_nome.Location = New Point(20, 220)
        txt_nome.Name = "txt_nome"
        txt_nome.Size = New Size(326, 23)
        txt_nome.TabIndex = 1
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.ForeColor = SystemColors.Info
        Label5.Location = New Point(20, 202)
        Label5.Name = "Label5"
        Label5.Size = New Size(106, 15)
        Label5.TabIndex = 35
        Label5.Text = "NOME COMPLETO"
        ' 
        ' txt_cpf
        ' 
        txt_cpf.Location = New Point(20, 165)
        txt_cpf.Mask = "999,999,999-00"
        txt_cpf.Name = "txt_cpf"
        txt_cpf.Size = New Size(89, 23)
        txt_cpf.TabIndex = 34
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.ForeColor = SystemColors.Info
        Label4.Location = New Point(20, 147)
        Label4.Name = "Label4"
        Label4.Size = New Size(28, 15)
        Label4.TabIndex = 33
        Label4.Text = "CPF"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = Color.Coral
        Label3.Location = New Point(138, 42)
        Label3.Name = "Label3"
        Label3.Size = New Size(439, 40)
        Label3.TabIndex = 32
        Label3.Text = "CADASTRO DE FUNCIONÁRIOS"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Black
        PictureBox2.BorderStyle = BorderStyle.Fixed3D
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(7, 3)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(113, 106)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 31
        PictureBox2.TabStop = False
        ' 
        ' OpenFileDialog1
        ' 
        OpenFileDialog1.FileName = "OpenFileDialog1"
        ' 
        ' btn_salvar
        ' 
        btn_salvar.Image = CType(resources.GetObject("btn_salvar.Image"), Image)
        btn_salvar.Location = New Point(97, 328)
        btn_salvar.Name = "btn_salvar"
        btn_salvar.Size = New Size(34, 30)
        btn_salvar.TabIndex = 64
        btn_salvar.UseVisualStyleBackColor = True
        ' 
        ' frm_adm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(676, 662)
        Controls.Add(TabControl1)
        Name = "frm_adm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "frm_adm"
        TabControl1.ResumeLayout(False)
        TabPage2.ResumeLayout(False)
        TabPage2.PerformLayout()
        CType(foto_3x4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents txt_city As MaskedTextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents txt_uf As MaskedTextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents btn_cadastrar As Button
    Friend WithEvents txt_telfixo As MaskedTextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txt_wpp As MaskedTextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txt_comp As MaskedTextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents cmb_data As DateTimePicker
    Friend WithEvents txt_bairro As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_n As MaskedTextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_rua As MaskedTextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_cep As MaskedTextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txt_email As MaskedTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txt_nome As MaskedTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents foto_3x4 As PictureBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Label2 As Label
    Friend WithEvents cmb_id_cargo As ComboBox
    Friend WithEvents btn_excluir As Button
    Friend WithEvents btn_salvar As Button
End Class
