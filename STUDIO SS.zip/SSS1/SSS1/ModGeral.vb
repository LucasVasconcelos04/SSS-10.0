﻿Module ModGeral

    Public sql, diretorio As String
    Public db As ADODB.Connection 'Variável do banco
    Public rs As ADODB.Recordset 'Variável da tabela
    Public resp As String
    Public cont As Integer

    Sub conectar_banco()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=SQLOLEDB; Data Source=DESKTOP-P6C6V5T; initial catalog=stb; trusted_connection=yes;")
            MsgBox("Conectado ao banco!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
        Catch ex As Exception
            MsgBox("Erro na conexão!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Sub limpar_campos_funcionarios()
        With frm_adm
            .txt_nome.Clear()
            .txt_email.Clear()
            .txt_telfixo.Clear()
            .txt_wpp.Clear()
            .txt_rua.Clear()
            .txt_bairro.Clear()
            .txt_uf.Clear()
            .txt_n.Clear()
            .cmb_id_cargo.SelectedIndex = -1
            .txt_comp.Clear()
            .txt_city.Clear()
            .txt_cep.Clear()
            .txt_cpf.Focus()
        End With
    End Sub

    Sub limpar_campos_cadastro()
        With frm_cadastro
            .txt_cpf.Clear()
            .txt_senha.Clear()
            .txt_rsenha.Clear()
            .chk_visu.Checked = False
            .chk_visu2.Checked = False
        End With
    End Sub

    Sub limpar_campos_login()
        With Formlogin
            .txt_cpf.Clear()
            .txt_senha.Clear()
            .chk_visu.Checked = False
            .txt_cpf.Focus()
        End With
    End Sub

End Module
