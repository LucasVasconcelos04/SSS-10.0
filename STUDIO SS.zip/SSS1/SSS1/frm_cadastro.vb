﻿Public Class frm_cadastro

    Private Sub btn_cadastrar_Click(sender As Object, e As EventArgs) Handles btn_cadastrar.Click
        Try
            If String.IsNullOrEmpty(txt_cpf.Text) Or String.IsNullOrEmpty(txt_senha.Text) Or String.IsNullOrEmpty(txt_rsenha.Text) Then
                MsgBox("Preencha todos os campos!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            ElseIf txt_senha.Text <> txt_rsenha.Text Then
                MsgBox("A senhas estão diferentes!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
            Else
                sql = "select * from tb_funcionarios where cpf='" & txt_cpf.Text & "'"
                rs = db.Execute(sql)
                If rs.EOF = True Then
                    MsgBox("CPF não cadastrado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                Else
                    sql = "update tb_funcionarios set senha_de_acesso = '" & txt_senha.Text & "' where cpf = '" & txt_cpf.Text & "'"
                    rs = db.Execute(sql)
                    MsgBox("Cadastro concluído com sucesso!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "ATENÇÃO")
                    limpar_campos_cadastro()
                End If
            End If
        Catch ex As Exception
            MsgBox("Erro ao gravar os dados!", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub

    Private Sub chk_visu_CheckedChanged(sender As Object, e As EventArgs) Handles chk_visu.CheckedChanged
        If chk_visu.Checked Then
            txt_senha.PasswordChar = ControlChars.NullChar
        Else
            txt_senha.PasswordChar = "*"
        End If
    End Sub

    Private Sub chk_visu2_CheckedChanged(sender As Object, e As EventArgs) Handles chk_visu2.CheckedChanged
        If chk_visu2.Checked Then
            txt_rsenha.PasswordChar = ControlChars.NullChar
        Else
            txt_rsenha.PasswordChar = "*"
        End If
    End Sub

    Private Sub btn_voltar_Click(sender As Object, e As EventArgs) Handles btn_voltar.Click
        Me.Hide()
        Formlogin.Show()
    End Sub
End Class
