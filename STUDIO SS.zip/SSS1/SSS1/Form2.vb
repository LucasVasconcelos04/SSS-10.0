﻿Public Class frm_matricula
    Private Sub img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click

    End Sub

    Private Sub txt_pesquisar_Click(sender As Object, e As EventArgs) Handles txt_pesquisar.Click

    End Sub
End Class