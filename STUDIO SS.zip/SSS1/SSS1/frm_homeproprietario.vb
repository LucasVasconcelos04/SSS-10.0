﻿Public Class frm_homeproprietario
    Private Sub btn_voltar_Click(sender As Object, e As EventArgs) Handles btn_voltar.Click
        Try
            resp = MsgBox("Tem certeza que deseja logar novamente?", MsgBoxStyle.Information + MsgBoxStyle.YesNo, "ATENÇÃO")
            If resp = vbYes Then
                Me.Hide()
                Formlogin.Show()
            Else
            End If
        Catch ex As Exception
        End Try
    End Sub
End Class