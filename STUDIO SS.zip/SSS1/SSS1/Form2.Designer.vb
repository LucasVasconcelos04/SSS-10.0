﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_matricula
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_matricula))
        TabControl1 = New TabControl()
        TabPage1 = New TabPage()
        PictureBox1 = New PictureBox()
        txt_residencia = New MaskedTextBox()
        Label12 = New Label()
        cmb_conclusao = New DateTimePicker()
        Label11 = New Label()
        cmb_inicio = New DateTimePicker()
        Label6 = New Label()
        txt_cep = New MaskedTextBox()
        Label9 = New Label()
        txt_bairro = New MaskedTextBox()
        Label5 = New Label()
        txt_endereco = New MaskedTextBox()
        Label2 = New Label()
        img_foto = New PictureBox()
        Label8 = New Label()
        cmb_data = New DateTimePicker()
        MaskedTextBox4 = New MaskedTextBox()
        Label7 = New Label()
        Label10 = New Label()
        cmb_curso = New ComboBox()
        Label4 = New Label()
        txt_email = New MaskedTextBox()
        EMAIL = New Label()
        txt_nome = New MaskedTextBox()
        Label1 = New Label()
        txt_cpf = New MaskedTextBox()
        Label3 = New Label()
        TabPage2 = New TabPage()
        DataGridView1 = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column4 = New DataGridViewTextBoxColumn()
        Column5 = New DataGridViewTextBoxColumn()
        Column6 = New DataGridViewTextBoxColumn()
        Column7 = New DataGridViewTextBoxColumn()
        Column8 = New DataGridViewTextBoxColumn()
        Column9 = New DataGridViewTextBoxColumn()
        Column10 = New DataGridViewTextBoxColumn()
        Column11 = New DataGridViewImageColumn()
        Column12 = New DataGridViewImageColumn()
        btn_gravar = New ToolStripButton()
        ToolStripLabel1 = New ToolStripLabel()
        txt_pesquisar = New ToolStripTextBox()
        ToolStripLabel2 = New ToolStripLabel()
        cmb_tipo = New ToolStripComboBox()
        ToolStrip1 = New ToolStrip()
        TabControl1.SuspendLayout()
        TabPage1.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(img_foto, ComponentModel.ISupportInitialize).BeginInit()
        TabPage2.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        ToolStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' TabControl1
        ' 
        TabControl1.Controls.Add(TabPage1)
        TabControl1.Controls.Add(TabPage2)
        TabControl1.Location = New Point(9, 38)
        TabControl1.Name = "TabControl1"
        TabControl1.SelectedIndex = 0
        TabControl1.Size = New Size(864, 629)
        TabControl1.TabIndex = 2
        ' 
        ' TabPage1
        ' 
        TabPage1.BackColor = Color.Black
        TabPage1.Controls.Add(PictureBox1)
        TabPage1.Controls.Add(txt_residencia)
        TabPage1.Controls.Add(Label12)
        TabPage1.Controls.Add(cmb_conclusao)
        TabPage1.Controls.Add(Label11)
        TabPage1.Controls.Add(cmb_inicio)
        TabPage1.Controls.Add(Label6)
        TabPage1.Controls.Add(txt_cep)
        TabPage1.Controls.Add(Label9)
        TabPage1.Controls.Add(txt_bairro)
        TabPage1.Controls.Add(Label5)
        TabPage1.Controls.Add(txt_endereco)
        TabPage1.Controls.Add(Label2)
        TabPage1.Controls.Add(img_foto)
        TabPage1.Controls.Add(Label8)
        TabPage1.Controls.Add(cmb_data)
        TabPage1.Controls.Add(MaskedTextBox4)
        TabPage1.Controls.Add(Label7)
        TabPage1.Controls.Add(Label10)
        TabPage1.Controls.Add(cmb_curso)
        TabPage1.Controls.Add(Label4)
        TabPage1.Controls.Add(txt_email)
        TabPage1.Controls.Add(EMAIL)
        TabPage1.Controls.Add(txt_nome)
        TabPage1.Controls.Add(Label1)
        TabPage1.Controls.Add(txt_cpf)
        TabPage1.Controls.Add(Label3)
        TabPage1.Location = New Point(4, 24)
        TabPage1.Name = "TabPage1"
        TabPage1.Padding = New Padding(3)
        TabPage1.Size = New Size(856, 601)
        TabPage1.TabIndex = 0
        TabPage1.Text = "DADOS PESSOAIS"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BorderStyle = BorderStyle.Fixed3D
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(730, 278)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(314, 298)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 45
        PictureBox1.TabStop = False
        ' 
        ' txt_residencia
        ' 
        txt_residencia.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        txt_residencia.Location = New Point(430, 225)
        txt_residencia.Name = "txt_residencia"
        txt_residencia.Size = New Size(287, 23)
        txt_residencia.TabIndex = 44
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label12.Location = New Point(430, 206)
        Label12.Name = "Label12"
        Label12.Size = New Size(206, 16)
        Label12.TabIndex = 43
        Label12.Text = "Nº DE RESIDÊNCIA E COMPLEMENTO"
        ' 
        ' cmb_conclusao
        ' 
        cmb_conclusao.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        cmb_conclusao.Format = DateTimePickerFormat.Short
        cmb_conclusao.Location = New Point(6, 488)
        cmb_conclusao.MaxDate = New Date(2019, 12, 31, 0, 0, 0, 0)
        cmb_conclusao.MinDate = New Date(1923, 1, 1, 0, 0, 0, 0)
        cmb_conclusao.Name = "cmb_conclusao"
        cmb_conclusao.Size = New Size(95, 23)
        cmb_conclusao.TabIndex = 42
        cmb_conclusao.Value = New Date(2019, 12, 31, 0, 0, 0, 0)
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label11.Location = New Point(6, 469)
        Label11.Name = "Label11"
        Label11.Size = New Size(190, 16)
        Label11.TabIndex = 41
        Label11.Text = "DATA DE CONCLUSÃO DO CURSO"
        ' 
        ' cmb_inicio
        ' 
        cmb_inicio.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        cmb_inicio.Format = DateTimePickerFormat.Short
        cmb_inicio.Location = New Point(6, 426)
        cmb_inicio.MaxDate = New Date(2019, 12, 31, 0, 0, 0, 0)
        cmb_inicio.MinDate = New Date(1923, 1, 1, 0, 0, 0, 0)
        cmb_inicio.Name = "cmb_inicio"
        cmb_inicio.Size = New Size(95, 23)
        cmb_inicio.TabIndex = 40
        cmb_inicio.Value = New Date(2019, 12, 31, 0, 0, 0, 0)
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label6.Location = New Point(6, 407)
        Label6.Name = "Label6"
        Label6.Size = New Size(154, 16)
        Label6.TabIndex = 39
        Label6.Text = "DATA DE INÍCIO DO CURSO"
        ' 
        ' txt_cep
        ' 
        txt_cep.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        txt_cep.Location = New Point(430, 31)
        txt_cep.Mask = "00000-9999"
        txt_cep.Name = "txt_cep"
        txt_cep.Size = New Size(115, 23)
        txt_cep.TabIndex = 38
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label9.Location = New Point(430, 12)
        Label9.Name = "Label9"
        Label9.Size = New Size(28, 16)
        Label9.TabIndex = 37
        Label9.Text = "CEP"
        ' 
        ' txt_bairro
        ' 
        txt_bairro.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        txt_bairro.Location = New Point(430, 158)
        txt_bairro.Name = "txt_bairro"
        txt_bairro.Size = New Size(287, 23)
        txt_bairro.TabIndex = 36
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label5.Location = New Point(430, 139)
        Label5.Name = "Label5"
        Label5.Size = New Size(48, 16)
        Label5.TabIndex = 35
        Label5.Text = "BAIRRO"
        ' 
        ' txt_endereco
        ' 
        txt_endereco.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        txt_endereco.Location = New Point(430, 94)
        txt_endereco.Name = "txt_endereco"
        txt_endereco.Size = New Size(287, 23)
        txt_endereco.TabIndex = 34
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label2.Location = New Point(430, 75)
        Label2.Name = "Label2"
        Label2.Size = New Size(66, 16)
        Label2.TabIndex = 33
        Label2.Text = "ENDEREÇO"
        ' 
        ' img_foto
        ' 
        img_foto.BackColor = SystemColors.Window
        img_foto.BorderStyle = BorderStyle.FixedSingle
        img_foto.Image = CType(resources.GetObject("img_foto.Image"), Image)
        img_foto.Location = New Point(430, 295)
        img_foto.Name = "img_foto"
        img_foto.Size = New Size(105, 91)
        img_foto.SizeMode = PictureBoxSizeMode.CenterImage
        img_foto.TabIndex = 32
        img_foto.TabStop = False
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label8.Location = New Point(430, 276)
        Label8.Name = "Label8"
        Label8.Size = New Size(38, 16)
        Label8.TabIndex = 31
        Label8.Text = "FOTO"
        ' 
        ' cmb_data
        ' 
        cmb_data.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        cmb_data.Format = DateTimePickerFormat.Short
        cmb_data.Location = New Point(15, 158)
        cmb_data.MaxDate = New Date(2019, 12, 31, 0, 0, 0, 0)
        cmb_data.MinDate = New Date(1923, 1, 1, 0, 0, 0, 0)
        cmb_data.Name = "cmb_data"
        cmb_data.Size = New Size(95, 23)
        cmb_data.TabIndex = 30
        cmb_data.Value = New Date(2019, 12, 31, 0, 0, 0, 0)
        ' 
        ' MaskedTextBox4
        ' 
        MaskedTextBox4.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        MaskedTextBox4.Location = New Point(6, 225)
        MaskedTextBox4.Mask = "(00) 00000-0000"
        MaskedTextBox4.Name = "MaskedTextBox4"
        MaskedTextBox4.Size = New Size(115, 23)
        MaskedTextBox4.TabIndex = 28
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label7.Location = New Point(6, 139)
        Label7.Name = "Label7"
        Label7.Size = New Size(134, 16)
        Label7.TabIndex = 29
        Label7.Text = "DATA DE NASCIMENTO"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label10.Location = New Point(6, 206)
        Label10.Name = "Label10"
        Label10.Size = New Size(90, 16)
        Label10.TabIndex = 27
        Label10.Text = "Nº DE CELULAR"
        ' 
        ' cmb_curso
        ' 
        cmb_curso.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        cmb_curso.FormattingEnabled = True
        cmb_curso.Items.AddRange(New Object() {"K-Pop dance", "Breakdance", "Dança conteporânea", "Dança de salão"})
        cmb_curso.Location = New Point(6, 364)
        cmb_curso.Name = "cmb_curso"
        cmb_curso.Size = New Size(186, 24)
        cmb_curso.TabIndex = 26
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label4.Location = New Point(6, 345)
        Label4.Name = "Label4"
        Label4.Size = New Size(45, 16)
        Label4.TabIndex = 25
        Label4.Text = "CURSO"
        ' 
        ' txt_email
        ' 
        txt_email.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        txt_email.Location = New Point(6, 295)
        txt_email.Name = "txt_email"
        txt_email.Size = New Size(287, 23)
        txt_email.TabIndex = 24
        ' 
        ' EMAIL
        ' 
        EMAIL.AutoSize = True
        EMAIL.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        EMAIL.Location = New Point(6, 276)
        EMAIL.Name = "EMAIL"
        EMAIL.Size = New Size(41, 16)
        EMAIL.TabIndex = 23
        EMAIL.Text = "EMAIL"
        ' 
        ' txt_nome
        ' 
        txt_nome.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        txt_nome.Location = New Point(6, 94)
        txt_nome.Name = "txt_nome"
        txt_nome.Size = New Size(331, 23)
        txt_nome.TabIndex = 22
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label1.Location = New Point(6, 75)
        Label1.Name = "Label1"
        Label1.Size = New Size(108, 16)
        Label1.TabIndex = 21
        Label1.Text = "NOME COMPLETO"
        ' 
        ' txt_cpf
        ' 
        txt_cpf.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        txt_cpf.Location = New Point(6, 31)
        txt_cpf.Mask = "000.000.000-00"
        txt_cpf.Name = "txt_cpf"
        txt_cpf.Size = New Size(74, 23)
        txt_cpf.TabIndex = 20
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Emoji", 9F, FontStyle.Regular, GraphicsUnit.Point)
        Label3.Location = New Point(6, 12)
        Label3.Name = "Label3"
        Label3.Size = New Size(28, 16)
        Label3.TabIndex = 19
        Label3.Text = "CPF"
        ' 
        ' TabPage2
        ' 
        TabPage2.BackColor = SystemColors.ControlText
        TabPage2.Controls.Add(DataGridView1)
        TabPage2.Location = New Point(4, 24)
        TabPage2.Name = "TabPage2"
        TabPage2.Padding = New Padding(3)
        TabPage2.Size = New Size(856, 601)
        TabPage2.TabIndex = 1
        TabPage2.Text = "LISTAGEM GERAL"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.BackgroundColor = SystemColors.ActiveBorder
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4, Column5, Column6, Column7, Column8, Column9, Column10, Column11, Column12})
        DataGridView1.Location = New Point(6, 6)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.ReadOnly = True
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(1059, 589)
        DataGridView1.TabIndex = 0
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "ID DA MATRÍCULA"
        Column1.Name = "Column1"
        Column1.ReadOnly = True
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "CPF DO ALUNO"
        Column2.Name = "Column2"
        Column2.ReadOnly = True
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "NOME DO ALUNO"
        Column3.Name = "Column3"
        Column3.ReadOnly = True
        ' 
        ' Column4
        ' 
        Column4.HeaderText = "CURSO"
        Column4.Name = "Column4"
        Column4.ReadOnly = True
        ' 
        ' Column5
        ' 
        Column5.HeaderText = "DIA"
        Column5.Name = "Column5"
        Column5.ReadOnly = True
        ' 
        ' Column6
        ' 
        Column6.HeaderText = "HORÁRIO"
        Column6.Name = "Column6"
        Column6.ReadOnly = True
        ' 
        ' Column7
        ' 
        Column7.HeaderText = "DATA DE INÍCIO"
        Column7.Name = "Column7"
        Column7.ReadOnly = True
        ' 
        ' Column8
        ' 
        Column8.HeaderText = "DATA DE CONCLUSÃO"
        Column8.Name = "Column8"
        Column8.ReadOnly = True
        ' 
        ' Column9
        ' 
        Column9.HeaderText = "PROFESSOR"
        Column9.Name = "Column9"
        Column9.ReadOnly = True
        ' 
        ' Column10
        ' 
        Column10.HeaderText = "STATUS"
        Column10.Name = "Column10"
        Column10.ReadOnly = True
        ' 
        ' Column11
        ' 
        Column11.HeaderText = "EDITAR"
        Column11.Image = CType(resources.GetObject("Column11.Image"), Image)
        Column11.Name = "Column11"
        Column11.ReadOnly = True
        ' 
        ' Column12
        ' 
        Column12.HeaderText = "MUDAR STATUS"
        Column12.Image = CType(resources.GetObject("Column12.Image"), Image)
        Column12.Name = "Column12"
        Column12.ReadOnly = True
        ' 
        ' btn_gravar
        ' 
        btn_gravar.DisplayStyle = ToolStripItemDisplayStyle.Image
        btn_gravar.Image = CType(resources.GetObject("btn_gravar.Image"), Image)
        btn_gravar.ImageTransparentColor = Color.Magenta
        btn_gravar.Name = "btn_gravar"
        btn_gravar.Size = New Size(23, 22)
        btn_gravar.Text = "ToolStripButton1"
        ' 
        ' ToolStripLabel1
        ' 
        ToolStripLabel1.BackColor = Color.Transparent
        ToolStripLabel1.ForeColor = SystemColors.HighlightText
        ToolStripLabel1.Name = "ToolStripLabel1"
        ToolStripLabel1.Size = New Size(185, 22)
        ToolStripLabel1.Text = "Digite um parâmetro de pesquisa:"
        ' 
        ' txt_pesquisar
        ' 
        txt_pesquisar.Name = "txt_pesquisar"
        txt_pesquisar.Size = New Size(100, 25)
        ' 
        ' ToolStripLabel2
        ' 
        ToolStripLabel2.ForeColor = SystemColors.HighlightText
        ToolStripLabel2.Name = "ToolStripLabel2"
        ToolStripLabel2.Size = New Size(60, 22)
        ToolStripLabel2.Text = "Selecione:"
        ' 
        ' cmb_tipo
        ' 
        cmb_tipo.Name = "cmb_tipo"
        cmb_tipo.Size = New Size(121, 25)
        ' 
        ' ToolStrip1
        ' 
        ToolStrip1.BackColor = SystemColors.HotTrack
        ToolStrip1.Items.AddRange(New ToolStripItem() {btn_gravar, ToolStripLabel1, txt_pesquisar, ToolStripLabel2, cmb_tipo})
        ToolStrip1.Location = New Point(0, 0)
        ToolStrip1.Name = "ToolStrip1"
        ToolStrip1.Padding = New Padding(0, 0, 2, 0)
        ToolStrip1.Size = New Size(861, 25)
        ToolStrip1.TabIndex = 1
        ToolStrip1.Text = "ToolStrip1"
        ' 
        ' frm_matricula
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaptionText
        ClientSize = New Size(861, 679)
        Controls.Add(TabControl1)
        Controls.Add(ToolStrip1)
        ForeColor = SystemColors.HighlightText
        Name = "frm_matricula"
        Text = "MATRÍCULA DE ALUNOS"
        TabControl1.ResumeLayout(False)
        TabPage1.ResumeLayout(False)
        TabPage1.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(img_foto, ComponentModel.ISupportInitialize).EndInit()
        TabPage2.ResumeLayout(False)
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ToolStrip1.ResumeLayout(False)
        ToolStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_nome As MaskedTextBox
    Friend WithEvents EMAIL As Label
    Friend WithEvents txt_email As MaskedTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cmb_curso As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents cmb_data As DateTimePicker
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_cep As MaskedTextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txt_bairro As MaskedTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_endereco As MaskedTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents img_foto As PictureBox
    Friend WithEvents MaskedTextBox4 As MaskedTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txt_residencia As MaskedTextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents cmb_conclusao As DateTimePicker
    Friend WithEvents Label11 As Label
    Friend WithEvents cmb_inicio As DateTimePicker
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Column10 As DataGridViewTextBoxColumn
    Friend WithEvents Column11 As DataGridViewImageColumn
    Friend WithEvents Column12 As DataGridViewImageColumn
    Friend WithEvents btn_gravar As ToolStripButton
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents txt_pesquisar As ToolStripTextBox
    Friend WithEvents ToolStripLabel2 As ToolStripLabel
    Friend WithEvents cmb_tipo As ToolStripComboBox
    Friend WithEvents ToolStrip1 As ToolStrip
End Class
