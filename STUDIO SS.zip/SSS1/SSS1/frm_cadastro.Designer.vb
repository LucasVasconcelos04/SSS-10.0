﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_cadastro
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(frm_cadastro))
        PictureBox1 = New PictureBox()
        chk_visu2 = New CheckBox()
        txt_rsenha = New MaskedTextBox()
        txt_senha = New MaskedTextBox()
        Label4 = New Label()
        Label3 = New Label()
        btn_cadastrar = New Button()
        btn_voltar = New Button()
        Label1 = New Label()
        txt_cpf = New MaskedTextBox()
        chk_visu = New CheckBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.BorderStyle = BorderStyle.Fixed3D
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(111, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(181, 175)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' chk_visu2
        ' 
        chk_visu2.AutoSize = True
        chk_visu2.Font = New Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        chk_visu2.ForeColor = SystemColors.Control
        chk_visu2.Location = New Point(161, 379)
        chk_visu2.Name = "chk_visu2"
        chk_visu2.Size = New Size(75, 17)
        chk_visu2.TabIndex = 22
        chk_visu2.Text = "Visualizar"
        chk_visu2.UseVisualStyleBackColor = True
        ' 
        ' txt_rsenha
        ' 
        txt_rsenha.Location = New Point(48, 372)
        txt_rsenha.Name = "txt_rsenha"
        txt_rsenha.PasswordChar = "*"c
        txt_rsenha.Size = New Size(100, 23)
        txt_rsenha.TabIndex = 20
        ' 
        ' txt_senha
        ' 
        txt_senha.Location = New Point(48, 301)
        txt_senha.Name = "txt_senha"
        txt_senha.PasswordChar = "*"c
        txt_senha.Size = New Size(100, 23)
        txt_senha.TabIndex = 19
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.ForeColor = SystemColors.HighlightText
        Label4.Location = New Point(48, 354)
        Label4.Name = "Label4"
        Label4.Size = New Size(90, 15)
        Label4.TabIndex = 15
        Label4.Text = "REPETIR SENHA"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.ForeColor = SystemColors.HighlightText
        Label3.Location = New Point(48, 283)
        Label3.Name = "Label3"
        Label3.Size = New Size(45, 15)
        Label3.TabIndex = 14
        Label3.Text = "SENHA"
        ' 
        ' btn_cadastrar
        ' 
        btn_cadastrar.BackColor = Color.Coral
        btn_cadastrar.Font = New Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        btn_cadastrar.Image = CType(resources.GetObject("btn_cadastrar.Image"), Image)
        btn_cadastrar.ImageAlign = ContentAlignment.TopCenter
        btn_cadastrar.Location = New Point(274, 404)
        btn_cadastrar.Name = "btn_cadastrar"
        btn_cadastrar.Size = New Size(82, 64)
        btn_cadastrar.TabIndex = 24
        btn_cadastrar.Text = "CADASTRAR"
        btn_cadastrar.TextAlign = ContentAlignment.BottomCenter
        btn_cadastrar.UseVisualStyleBackColor = False
        ' 
        ' btn_voltar
        ' 
        btn_voltar.Image = CType(resources.GetObject("btn_voltar.Image"), Image)
        btn_voltar.Location = New Point(12, 12)
        btn_voltar.Name = "btn_voltar"
        btn_voltar.Size = New Size(41, 34)
        btn_voltar.TabIndex = 25
        btn_voltar.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.ForeColor = SystemColors.HighlightText
        Label1.Location = New Point(48, 216)
        Label1.Name = "Label1"
        Label1.Size = New Size(28, 15)
        Label1.TabIndex = 26
        Label1.Text = "CPF"
        ' 
        ' txt_cpf
        ' 
        txt_cpf.Location = New Point(48, 234)
        txt_cpf.Mask = "000,000,000-00"
        txt_cpf.Name = "txt_cpf"
        txt_cpf.Size = New Size(78, 23)
        txt_cpf.TabIndex = 27
        ' 
        ' chk_visu
        ' 
        chk_visu.AutoSize = True
        chk_visu.Font = New Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point)
        chk_visu.ForeColor = Color.Transparent
        chk_visu.Location = New Point(162, 306)
        chk_visu.Name = "chk_visu"
        chk_visu.Size = New Size(75, 17)
        chk_visu.TabIndex = 28
        chk_visu.Text = "Visualizar"
        chk_visu.UseVisualStyleBackColor = True
        ' 
        ' frm_cadastro
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Black
        ClientSize = New Size(380, 480)
        Controls.Add(chk_visu)
        Controls.Add(txt_cpf)
        Controls.Add(Label1)
        Controls.Add(btn_voltar)
        Controls.Add(btn_cadastrar)
        Controls.Add(chk_visu2)
        Controls.Add(txt_rsenha)
        Controls.Add(txt_senha)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(PictureBox1)
        Name = "frm_cadastro"
        StartPosition = FormStartPosition.CenterScreen
        Text = "NOVO USUÁRIO"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents chk_visu2 As CheckBox
    Friend WithEvents txt_rsenha As MaskedTextBox
    Friend WithEvents txt_senha As MaskedTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btn_cadastrar As Button
    Friend WithEvents btn_voltar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_cpf As MaskedTextBox
    Friend WithEvents chk_visu As CheckBox
End Class
